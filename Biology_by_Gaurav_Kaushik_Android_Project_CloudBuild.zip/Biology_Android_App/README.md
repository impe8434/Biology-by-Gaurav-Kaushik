# Biology by Gaurav Kaushik — Android application

This is an Android Studio project wrapping the existing complete Cellora-inspired Biology guide in a native Android WebView. All 19 chapters and the existing HTML learning features are bundled locally, so the notes work without internet once the app is installed.

## Included
- Native Android launcher application (application ID `com.gauravkaushik.biology`)
- Full 19-chapter guide bundled at `app/src/main/assets/index.html`
- Offline-first local HTML loading; browser localStorage persists topic progress, bookmarks, quiz answers/best score and theme on-device
- Native Android print dialog through the existing Print / Save as PDF action
- Native share sheet for exported study-progress JSON
- Existing Cellora colours, animations, topic slider/search, responsive tables, quiz and study controls
- Android back navigation, app icon and app label

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`Biology_Android_App`) in Android Studio.
3. Allow Gradle sync to finish (Android Gradle Plugin 8.7.3 is specified in `build.gradle`).
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Debug APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

The build needs Android Studio/SDK and an internet connection on first Gradle sync to download the Android Gradle Plugin. This project source package was generated in an environment without an installed Android SDK/Gradle, so no APK binary is claimed to have been compiled here.

## Content preservation
The HTML `<title>` remains `BIOLOGY | NCERT Class XI Biology · BPSC CSE Visual Revision Guide`; the Android launcher label is `Biology by Gaurav Kaushik`.

## Build without a laptop (cloud build from Android phone)
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. It compiles the APK on GitHub's cloud runner, so you do not need to install Android Studio, Gradle, or an SDK on your phone.

1. On your phone, create a GitHub repository and upload the **contents** of this project (including the hidden `.github/workflows/build-apk.yml` file). If the mobile upload flow hides hidden folders, create `.github/workflows/build-apk.yml` in GitHub using **Add file → Create new file**, then paste the workflow from this project.
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab and select **Build Biology Android APK**. If it has not run automatically, tap **Run workflow**.
4. When the run finishes successfully, open that run and download the artifact named `Biology-by-Gaurav-Kaushik-debug-apk`.
5. Extract the artifact ZIP on your phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager.

This cloud workflow creates a debug APK for personal installation; it is not a Play Store-signed release. The APK is not included in this source ZIP because no Android SDK/build engine is available in the current workspace to compile it locally.
