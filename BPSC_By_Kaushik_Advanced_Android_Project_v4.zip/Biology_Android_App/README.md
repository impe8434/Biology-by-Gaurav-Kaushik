# BPSC By Kaushik — Android Project v4

A lightweight Android WebView app with a navy–teal/cyan study dashboard and offline Biology guide.

## What's in this version
- App label: **BPSC By Kaushik**.
- Launcher icon: a single glowing **G** (not BG/BK).
- Premium dark navy, teal and cyan styling inspired by the supplied reference image.
- Dashboard sections for Science, History, Polity, Geography, Bihar Special, Current Affairs, Practice, BPSC Mains and PYQ Centre.
- Existing NCERT Class XI Biology chapters remain in the Biology guide and are opened from **Science → Biology** only.
- Separate 12-month current-affairs navigation (October 2025–October 2026), official-source directory, and a small set of source-linked entries where available. Months without a verified bundled digest open an archive and are clearly labelled; they are not falsely presented as completed digests.
- Daily mission checklist, local progress, focus timer and offline rule-based Kaushik Mentor.
- Android Back returns from a topic to its section, from a section to Home, and requires a second Back press within 2 seconds to close from Home.

## Honest feature status
The subject navigation for Physics, Chemistry, History, Polity, Geography, Bihar Special and Mains is a framework; complete chapter notes and authenticated BPSC PYQ banks have not yet been bundled. The Kaushik Mentor is an offline rule-based helper, not a connected generative AI. Real AI requires a secure backend/API, privacy controls and network access; do not embed a secret API key in the APK. Current-affairs content is not yet a complete event-by-event one-year digest. Coaching compilations (Eduteria, Aspire, Disha, Drishti) are listed as secondary revision sources; copyrighted book text is not reproduced.

## Build with GitHub Actions
1. Upload `BPSC_By_Kaushik_Advanced_Android_Project_v4.zip` to the root of your existing repository.
2. In the repository's `.github/workflows/build-apk.yml`, set the ZIP filename in the `unzip` command to `BPSC_By_Kaushik_Advanced_Android_Project_v4.zip`.
3. Keep the Android SDK setup that previously worked for your repository.
4. Run the workflow and download the APK from Artifacts.

A successful cloud build and real-device battery/performance testing have not been confirmed by this source project alone.
