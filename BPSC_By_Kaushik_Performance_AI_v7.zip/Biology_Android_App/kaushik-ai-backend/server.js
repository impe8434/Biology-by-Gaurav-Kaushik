import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';

const app = express();
app.disable('x-powered-by');
app.use(cors({ origin: (origin, cb) => {
  // Android WebView opened from a bundled file may send no Origin or "null".
  // Restrict browser origins with ALLOWED_ORIGINS when hosting a web version.
  const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
  if (!origin || origin === 'null' || allowed.length === 0 || allowed.includes(origin)) return cb(null, true);
  return cb(new Error('Origin not allowed'));
}}));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'Kaushik AI' }));

app.post('/api/mentor', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  if (!message) return res.status(400).json({ error: 'Please provide a question.' });
  if (message.length > 12000) return res.status(413).json({ error: 'Question is too long; limit is 12,000 characters.' });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'AI provider is not configured on the server. Add OPENAI_API_KEY in the hosting service environment variables.' });
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 55_000, maxRetries: 1 });
    const instructions = `You are Kaushik AI, a professional mentor for the BPSC Combined Competitive Examination in Bihar, India. Be a precise and encouraging tutor, not a generic chatbot. Respond in the language used by the student. Give a direct answer first, then a clear step-by-step explanation, key facts, dates/articles/definitions, exam relevance, common traps, and a short revision summary. For MCQs, explain every option. For Mains, use an introduction, structured headings, analysis, balanced perspectives, Bihar examples only when relevant and reliable, and a conclusion. Never invent official BPSC PYQs, sources, citations or current facts. If a fact may have changed, state that it needs verification. Distinguish official PYQs from original practice questions. If the question is ambiguous, ask one focused clarification. Keep formatting clean and readable on a phone.`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5-mini',
      instructions,
      input: message,
      max_output_tokens: 1800,
      store: false
    });
    const reply = (response.output_text || '').trim();
    if (!reply) return res.status(502).json({ error: 'The AI provider returned an empty answer. Please retry.' });
    return res.json({ reply, model: response.model || process.env.OPENAI_MODEL || 'gpt-5-mini' });
  } catch (err) {
    console.error('Kaushik AI provider error:', err?.status || '', err?.message || 'unknown');
    if (err?.status === 401) return res.status(502).json({ error: 'AI provider authentication failed. Check the server-side API key.' });
    if (err?.status === 429) return res.status(429).json({ error: 'AI provider rate limit or quota reached. Check billing/limits and retry later.' });
    return res.status(502).json({ error: 'The AI service could not complete this request. Check server logs and provider availability.' });
  }
});
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Kaushik AI backend listening on ${port}`));
