# Kaushik AI backend (required for online answers)

The Android app cannot safely contain an AI provider key. This small Node.js service proxies questions to the OpenAI Responses API and returns `{ "reply": "..." }`, which the app understands.

## Deploy
1. Put this `kaushik-ai-backend` folder in a GitHub repository (or copy its files into a new repository root).
2. Deploy it to a Node.js HTTPS host that supports environment variables. Set the start command to `npm start`.
3. In the hosting dashboard, set `OPENAI_API_KEY` to your own API key and optionally `OPENAI_MODEL` (default `gpt-5-mini`). Never commit the key or place it in the APK.
4. Wait for deployment. Open `https://YOUR-HOST/health`; it should return `{"status":"ok","service":"Kaushik AI"}`.
5. In the app, open Kaushik AI and set the endpoint to `https://YOUR-HOST/api/mentor`, tap **Test connection**, then ask a question.

## Troubleshooting
- `503`: server is missing `OPENAI_API_KEY`.
- `502` authentication: key is invalid or provider project is not authorised.
- `429`: provider quota/rate limit or backend rate limit.
- `Could not reach backend`: check deployment, HTTPS URL, network and CORS.
- AI API usage may incur charges. Set provider budget/usage limits.

This service includes basic request validation and rate limiting; for public production use, add user authentication, stronger abuse protection, monitoring and cost limits. It does not promise exam selection or official scoring.
