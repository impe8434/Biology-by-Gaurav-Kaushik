package com.gauravkaushik.biology;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.os.SystemClock;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String APP_TITLE = "BPSC By Kaushik";
    private long lastBackPressedAt = 0L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(22,20,43));
        getWindow().setNavigationBarColor(Color.rgb(17,22,41));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(6,19,38));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        // DOM storage is required for saved progress; legacy WebSQL database is not needed.
        webView.getSettings().setDatabaseEnabled(false);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidApp");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                android.util.Log.d("BiologyWeb", message.message() + " (" + message.lineNumber() + ")");
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Keep internal topic anchors and bundled files inside the offline app.
                if ("file".equals(uri.getScheme()) || uri.toString().startsWith("about:")) return false;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if (scheme.equals("https") || scheme.equals("http")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { Toast.makeText(MainActivity.this, "No browser available", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return true;
            }
        });
        setContentView(webView);
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(APP_TITLE);
                    printManager.print(APP_TITLE, adapter, new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new android.print.PrintAttributes.Resolution("biology", "Biology", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Unable to open print dialog on this device", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void exportProgress(String json) {
            runOnUiThread(() -> {
                try {
                    File out = new File(getExternalFilesDir(null), "biology-study-progress.json");
                    try (FileOutputStream stream = new FileOutputStream(out)) {
                        stream.write(json.getBytes(StandardCharsets.UTF_8));
                    }
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("application/json");
                    share.putExtra(Intent.EXTRA_TEXT, json);
                    share.putExtra(Intent.EXTRA_SUBJECT, "Biology study progress");
                    startActivity(Intent.createChooser(share, "Share study progress JSON"));
                    Toast.makeText(MainActivity.this, "Progress exported for sharing", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Could not export progress", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        // First let the in-app navigation return from a topic to its parent, then to Home.
        webView.evaluateJavascript("(function(){if(window.bkHandleBack){return window.bkHandleBack();}if(document.getElementById('bk-detail')&&document.getElementById('bk-detail').classList.contains('active')){window.bkShowHome();return 'handled';}if(!document.body.classList.contains('bpsc-home-visible')){window.bkShowHome();return 'handled';}return 'home';})()", value -> {
            if (isFinishing()) return;
            if ("\"handled\"".equals(value)) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastBackPressedAt < 2000L) {
                finish();
            } else {
                lastBackPressedAt = now;
                Toast.makeText(MainActivity.this, "Tap Back again to close BPSC By Kaushik", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
