# BPSC Record Android app source

## What this is
A native Android WebView wrapper around the existing BPSC Record standalone app. It loads the app from Android's asset loader using a stable HTTPS-like origin so browser storage APIs have a consistent origin. Exported Blob files are bridged to Android and saved under `Downloads/BPSC Record` on Android 10+.

## Build an APK without a laptop (using GitHub on Android)
1. Create a new empty repository on GitHub using the Android browser/app.
2. Upload the contents of this folder (all files and folders) to the repository. Keep `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab and select **Build BPSC Record APK**.
4. Tap **Run workflow** (or push to `main` to trigger it).
5. Wait for the run to finish successfully. Open the completed run, scroll to **Artifacts**, and download `BPSC-Record-debug-APK`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that source.

## Features in this wrapper
- Full-screen mobile app experience with Android status/navigation bar styling.
- Local bundled app; no internet needed to open the study app after installation.
- JavaScript + DOM storage enabled for app functionality.
- Android back button support.
- Blob-based exports are routed to `Downloads/BPSC Record` on Android 10+.
- Original local question bank and app functions are bundled in `app/src/main/assets/index.html`.

## Known content limitations (important)
This APK wrapper does not magically complete the content audit. The current app has 4,561 extracted Prelims records, not certified unique official PYQs. The 1,580 Mains question candidates are still review candidates and are not all individually verified/model-answered. Every answer key, explanation and source-page match still needs editorial verification. The app is an offline-capable preparation workspace, but the completeness target must not be represented as finished until the source audit says so.

## Build details
- Application ID: `in.gauravkaushik.bpscrecord`
- Version: 1.0.0
- Min Android API: 26 (Android 8.0)
- Target SDK: 35
- Build: GitHub Actions, Gradle 8.9, JDK 17
