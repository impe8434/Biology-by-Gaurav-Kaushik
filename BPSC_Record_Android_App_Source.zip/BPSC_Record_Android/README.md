# BPSC Record — Audit-aware mobile-first build

## Open on Android
Open `BPSC_Record_Final.html` for local testing. It contains the application UI, CSS, JavaScript, and the extracted Prelims bank embedded into the page. IndexedDB/local browser storage is browser-profile specific.

For reliable PWA installation and service-worker offline caching, host the project over HTTPS and open it in Chrome. Choose Install app/Add to Home screen. Save portable backups into an Android Files folder named `BPSC Record`.

## Included deliverables
- `BPSC_Record_Final.html` — standalone application.
- `question_bank.json` — 4,561 extracted Prelims records.
- `mains_question_candidates.json` — 1,580 Mains question candidates, all marked Needs Review.
- `all_source_pages.json` — page-by-page extracted text for all seven supplied PDFs.
- `page_audit.csv` / `page_audit.json` — status, character count and question-cue counts for every PDF page.
- `subject_chapter_counts.json` — subject totals and chapter-wise record counts.
- `FINAL_SOURCE_AUDIT.json` — coverage, status and explicit limitations.
- `manifest.webmanifest` / `sw.js` — PWA configuration for HTTPS hosting.

## Honest completeness status
All 3,076 PDF pages have been text-processed or explicitly flagged for review/OCR. The page inventory status is not the same as question-level completeness. The current structured Prelims bank has 4,561 records extracted from five Prelims sources. The two Mains PDFs have 1,580 conservatively extracted question candidates, all marked `Needs Review`; these are not yet fully deduplicated or manually checked as exact prompts. All extracted answer keys/explanations require source/editorial verification. No claim is made that every question is already captured or that every answer is correct.

## Verification
Automated checks cover syntax, direct DOM references, manifest JSON, record fields, page count reconciliation and ZIP integrity. Manual page-by-page question reconciliation, answer-key verification and real Android acceptance testing remain required for a true final release.
