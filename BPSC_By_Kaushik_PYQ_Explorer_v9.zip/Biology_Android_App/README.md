# BPSC By Kaushik — Performance + Kaushik AI update

## What changed
- Android WebView gets a lightweight visual profile: continuous ambient orb animations, blur and hover transforms are disabled only in the native app; colours and card design remain.
- Kaushik AI has a connection test, timeout handling, clearer errors and phone-friendly answer display.
- Included `kaushik-ai-backend/` is a deploy-ready Node.js starter using the OpenAI Responses API.
- The API key is kept on the backend, not in the APK.

## Important: online AI activation
The ZIP cannot make live AI work until you deploy the backend and set `OPENAI_API_KEY` in the hosting provider's environment settings. Follow `kaushik-ai-backend/README.md`. Then enter the deployed `https://YOUR-HOST/api/mentor` URL in the app and tap Test connection. Provider usage may cost money.

## Build APK
Upload this project ZIP to your existing repository, change the `unzip` filename in `.github/workflows/build-apk.yml`, and run GitHub Actions. Keep the working Android SDK setup.


## PYQ Explorer integration (v9)
- Added a themed PYQ Explorer inside the app's existing home navigation.
- Provides subject cards and direct links to the public BPSC PYQ question banks, paper archive, and mock-test page.
- Question-bank counts/categories reflect the source website as checked in October 2026 and may change.
- The app links to the source rather than copying its full question bank; the linked question content and online tests require internet access.
- Existing Biology guide and navy/teal/cyan design are retained.
